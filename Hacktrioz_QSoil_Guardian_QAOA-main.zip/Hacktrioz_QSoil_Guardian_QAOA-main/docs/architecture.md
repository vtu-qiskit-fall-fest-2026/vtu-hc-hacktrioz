# Architecture and algorithm

1. Four synthetic soil zones are assigned priority weights.
2. The user-defined budget is the number of zones to select.
3. Binary decision `x_i=1` means selecting zone i.
4. The objective is `E(x) = -sum(w_i*x_i) + P*(sum(x_i)-B)^2`. The penalty discourages bitstrings that violate the fixed allocation budget.
5. A QAOA circuit starts in a uniform superposition, applies a cost unitary (RZ and RZZ gates) and an X mixer (RX gates) for p layers.
6. SciPy COBYLA tunes gamma/beta parameters using exact statevector probabilities.
7. Qiskit AerSimulator samples the optimized circuit; bitstrings are decoded and scored.
8. Exhaustive classical search gives an exact baseline for this tiny problem.

## Limitations

QAOA is a heuristic; parameter optimization and measurement are stochastic. This starter is a classical simulation of a quantum algorithm, not execution on quantum hardware. Four variables are too small to establish advantage over classical methods. No farm trials, water-savings measurements, or validated agronomic claims are included.
