"""Run the QSoil Guardian QAOA demonstration."""
import json
from src.optimizer import DEFAULT_ZONES, exact_classical_baseline, run_qaoa


def main():
    priorities = [z["priority"] for z in DEFAULT_ZONES]
    budget = 2
    print("\n=== QSoil Guardian | QAOA hybrid quantum-classical demo ===")
    print("Synthetic demonstration values only; not field readings or agronomic advice.\n")
    for z in DEFAULT_ZONES:
        print(f"{z['name']}: moisture={z['moisture']}%, priority={z['priority']:.2f}")
    baseline = exact_classical_baseline(priorities, budget)
    print(f"\nExact classical optimum: {baseline}")
    result = run_qaoa(priorities, budget=budget, p=1)
    print("\nQAOA experiment:")
    print(json.dumps({
        "depth_p": result["p"],
        "shots": result["shots"],
        "optimizer_success": result["optimizer_success"],
        "expected_energy": round(result["expected_energy"], 4),
        "valid_shot_fraction": round(result["valid_shot_fraction"], 4),
        "best_valid_sample": result["best_valid_sample"],
    }, indent=2))
    print("\nInterpretation: QAOA is a heuristic and may not sample the optimum every run.")
    print("This runs on AerSimulator on a classical computer; no quantum advantage is claimed.")


if __name__ == "__main__":
    main()
