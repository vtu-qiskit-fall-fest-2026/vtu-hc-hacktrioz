"""Classical optimizer around a QAOA circuit, plus exact baseline."""
from __future__ import annotations
from itertools import combinations
import numpy as np
from scipy.optimize import minimize
from qiskit_aer import AerSimulator
from src.circuit import build_qaoa_circuit, energy, expected_energy


DEFAULT_ZONES = [
    {"name": "Zone A", "moisture": 22.0, "target": 25.0, "priority": 0.12},
    {"name": "Zone B", "moisture": 11.0, "target": 25.0, "priority": 0.56},
    {"name": "Zone C", "moisture": 28.0, "target": 25.0, "priority": 0.00},
    {"name": "Zone D", "moisture": 16.0, "target": 25.0, "priority": 0.36},
]


def exact_classical_baseline(priorities: list[float], budget: int) -> dict:
    if not 0 <= budget <= len(priorities):
        raise ValueError("Budget must be between zero and the number of zones.")
    candidates = []
    for chosen in combinations(range(len(priorities)), budget):
        bits = "".join("1" if i in chosen else "0" for i in range(len(priorities)))
        candidates.append({"bitstring": bits, "score": sum(priorities[i] for i in chosen)})
    return max(candidates, key=lambda item: item["score"])


def run_qaoa(priorities: list[float], budget: int = 2, p: int = 1, shots: int = 2048, seed: int = 7) -> dict:
    if len(priorities) != 4:
        raise ValueError("This starter is configured for exactly four zones.")
    if p < 1:
        raise ValueError("QAOA depth p must be at least 1.")
    rng = np.random.default_rng(seed)
    initial = np.concatenate([rng.uniform(0, np.pi, p), rng.uniform(0, np.pi, p)])

    objective = lambda params: expected_energy(priorities, budget, params)
    result = minimize(objective, initial, method="COBYLA", options={"maxiter": 100, "rhobeg": 0.5})

    circuit = build_qaoa_circuit(priorities, budget, result.x, measure=True)
    counts = AerSimulator().run(circuit, shots=shots, seed_simulator=seed).result().get_counts()

    decoded = []
    for displayed, count in counts.items():
        bits = displayed[::-1]
        selected = [i for i, b in enumerate(bits) if b == "1"]
        valid = len(selected) == budget
        score = sum(priorities[i] for i in selected) if valid else None
        decoded.append({
            "bitstring": bits,
            "count": int(count),
            "probability": count / shots,
            "valid_budget": valid,
            "score": float(score) if score is not None else None,
            "energy": float(energy(bits, priorities, budget)),
        })
    valid = [x for x in decoded if x["valid_budget"]]
    valid.sort(key=lambda x: (x["score"], x["count"]), reverse=True)
    return {
        "p": p,
        "shots": shots,
        "parameters": [float(v) for v in result.x],
        "optimizer_success": bool(result.success),
        "optimizer_message": str(result.message),
        "expected_energy": float(result.fun),
        "counts": counts,
        "samples": decoded,
        "best_valid_sample": valid[0] if valid else None,
        "valid_shot_fraction": sum(x["count"] for x in valid) / shots,
    }
