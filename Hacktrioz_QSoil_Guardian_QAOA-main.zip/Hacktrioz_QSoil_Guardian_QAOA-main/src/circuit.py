"""QAOA circuit for fixed-budget irrigation allocation.

A bit x_i=1 means selecting soil zone i. We minimize
E(x) = -sum(priority_i*x_i) + penalty*(sum(x_i)-budget)^2.
This is a genuine QAOA-style cost/mixer circuit, simulated locally.
"""
from __future__ import annotations
import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector


def energy(bitstring: str, priorities: list[float], budget: int, penalty: float = 3.0) -> float:
    chosen = sum(bit == "1" for bit in bitstring)
    reward = sum(float(priorities[i]) for i, bit in enumerate(bitstring) if bit == "1")
    return -reward + penalty * (chosen - budget) ** 2


def _cost_coefficients(priorities: list[float], budget: int, penalty: float):
    """Return constant, Z_i coefficients and Z_i Z_j coefficients for H."""
    n = len(priorities)
    # x_i=(1-Z_i)/2; expand -sum(w_i*x_i)+P(sum(x_i)-B)^2
    # Ignore constant (global phase), preserve all Z and ZZ terms.
    z = []
    n = len(priorities)
    for i, w in enumerate(priorities):
        # Linear contribution plus the Z terms arising from every pair x_i*x_j.
        # x_i=(1-Z_i)/2 and each pair contributes -P/2 to each involved Z_i.
        a = -float(w) + penalty * (1 - 2 * budget)
        z.append(-a / 2.0 - penalty * (n - 1) / 2.0)
    zz = {(i, j): penalty / 2.0 for i in range(n) for j in range(i+1, n)}
    return z, zz


def build_qaoa_circuit(priorities: list[float], budget: int, params, penalty: float = 3.0, measure: bool = False):
    """Build depth-p QAOA circuit; params = [gamma_0..gamma_(p-1), beta_0..beta_(p-1)]."""
    n = len(priorities)
    p = len(params) // 2
    if n < 1 or not 0 <= budget <= n:
        raise ValueError("Need at least one zone and a budget between zero and zone count.")
    if len(params) % 2:
        raise ValueError("QAOA params must contain equal gamma and beta arrays.")
    z_coeffs, zz_coeffs = _cost_coefficients(priorities, budget, penalty)
    gammas, betas = params[:p], params[p:]
    qc = QuantumCircuit(n)
    qc.h(range(n))
    for gamma, beta in zip(gammas, betas):
        # exp(-i gamma * h_i Z_i) up to convention/global phase
        for i, coeff in enumerate(z_coeffs):
            qc.rz(float(2 * gamma * coeff), i)
        # exp(-i gamma * J_ij Z_i Z_j)
        for (i, j), coeff in zz_coeffs.items():
            qc.rzz(float(2 * gamma * coeff), i, j)
        # Standard X mixer
        for i in range(n):
            qc.rx(float(2 * beta), i)
    if measure:
        qc.measure_all()
    return qc


def expected_energy(priorities: list[float], budget: int, params, penalty: float = 3.0) -> float:
    qc = build_qaoa_circuit(priorities, budget, params, penalty)
    probs = Statevector.from_instruction(qc).probabilities()
    # Qiskit statevector index bits are little-endian; format as zone-order string.
    result = 0.0
    for index, prob in enumerate(probs):
        bits = format(index, f"0{len(priorities)}b")[::-1]
        result += float(prob) * energy(bits, priorities, budget, penalty)
    return result
