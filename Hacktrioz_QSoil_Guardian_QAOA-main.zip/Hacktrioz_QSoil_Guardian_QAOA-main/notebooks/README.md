# Notebook workflow

Optional: create `exploration.ipynb` in JupyterLab to visualize circuit diagrams, sampled bitstring counts, and baseline comparison. The runnable source of truth is `src/main.py`; do not claim a notebook was run unless you actually execute it.
