# Data and assumptions

The four moisture readings and priority scores in `src/optimizer.py` are synthetic examples chosen to make the prototype runnable without sensors or API keys. They are not field data, validated agronomic recommendations, or proof of water savings.

Potential public-data starting points:
- NASA-USDA Global Soil Moisture Data: https://earth.gsfc.nasa.gov/hydro/data/nasa-usda-global-soil-moisture-data
- ISRIC SoilGrids: https://isric.org/explore/soilgrids/

Those sources have their own spatial resolution and modeling limitations; do not describe them as real-time readings from a specific farm plot.
