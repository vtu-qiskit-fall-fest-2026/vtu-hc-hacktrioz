# Hacktrioz — QSoil Guardian (QAOA edition)

**Team ID:** `VTU-QFF-HC-0019` · **Tier:** Both  
**Event:** VTU-QFF Hackathon — VTU-Qiskit Fall Fest 2026

> Before submission, replace team-member placeholders and confirm the official track/category with the organizers.

## Team Members (GitHub IDs)

| # | Name | GitHub username | Role |
|---|---|---|---|
| 1 | ADD REAL NAME | ADD REAL USERNAME | Team Lead |
| 2 | ADD REAL NAME | ADD REAL USERNAME | Developer |
| 3 | ADD REAL NAME | ADD REAL USERNAME | Developer |

## Problem Statement

Water allocation is a constrained decision problem: different soil zones can have different irrigation priorities, but only a limited number of zones can be serviced in one allocation round. This project models a small fixed-budget allocation task and explores how a quantum optimization algorithm can generate candidate allocations.

**Why it matters:** Precision allocation is a plausible sustainability application, but this prototype does not measure or prove real-world water savings.

**Track / Category:** Sustainability / quantum optimization; confirm official track and online/offline category.

## Proposed Solution

QSoil Guardian formulates a four-zone irrigation selection problem as a binary optimization objective and uses a QAOA (Quantum Approximate Optimization Algorithm) circuit with a classical COBYLA optimizer. It samples candidate bitstrings on Qiskit Aer and compares them with an exact exhaustive classical baseline.

**Key idea:** Encode allocation reward and a fixed-budget penalty in a cost Hamiltonian, alternate QAOA cost and mixer layers, then decode measured bitstrings.

**Why this works:** The formulation rewards high-priority zones and penalizes allocations that select the wrong number of zones. The classical exact baseline provides a transparent benchmark.

## Approach & Architecture

```mermaid
flowchart LR
  A[Synthetic soil-zone priorities] --> B[Binary objective + budget penalty]
  B --> C[QAOA cost and mixer circuit]
  C --> D[COBYLA tunes gamma and beta]
  D --> E[AerSimulator measurements]
  E --> F[Decode and score bitstrings]
  F --> G[Compare with exact classical baseline]
```

1. **Input:** Four synthetic moisture values and illustrative zone priorities.
2. **Preprocessing:** Convert priorities to weights and specify the number of zones to select.
3. **Quantum core:** QAOA cost unitary using RZ/RZZ gates and an RX mixer, with tunable gamma/beta parameters.
4. **Optimization:** COBYLA minimizes expected penalized energy estimated from statevector probabilities.
5. **Post-processing:** AerSimulator measurements are decoded; valid fixed-budget bitstrings are ranked by priority score.
6. **Output:** Best valid sampled allocation, valid-shot fraction, and exact classical optimum.

## Tech Stack

- Python 3.11+
- Qiskit `>=1.0`
- Qiskit Aer / AerSimulator
- SciPy COBYLA
- NumPy
- VS Code, virtual environment (`venv`)
- pytest; Git + GitHub

## Project Structure

```text
vtu-hc-hacktrioz/
├── README.md
├── README_PROJECT_DRAFT.md
├── requirements.txt
├── pyproject.toml
├── .gitignore
├── src/
│   ├── __init__.py
│   ├── circuit.py
│   ├── optimizer.py
│   └── main.py
├── data/README.md
├── docs/architecture.md
└── tests/test_circuit.py
```

## How to Run (Windows PowerShell)

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m src.main
pytest -q
```

If `py -3.11` is unavailable, check `py --list` and use an installed Python 3.11+ version. If PowerShell blocks activation, use Command Prompt and run `.venv\Scripts\activate.bat`.

## Results and Evidence

Run the program and record the actual outputs for your machine before submission. Compare QAOA's best valid sampled score and valid-shot fraction with the exact classical optimum. Results may vary by seed, optimizer behavior, and sampling.

**Scientific honesty:** this is a small classical simulation of QAOA. It does not demonstrate quantum advantage, live soil sensing, validated agronomic recommendations, or measured water savings.

## Submission checklist

- [ ] Replace member names and GitHub usernames with real details.
- [ ] Confirm official track/category and presentation requirements.
- [ ] Install dependencies in a clean environment.
- [ ] Run `python -m src.main`.
- [ ] Run `pytest -q`.
- [ ] Add a genuine screenshot/video link after recording.
- [ ] Commit files, push to GitHub, and verify a clean clone runs.
- [ ] Submit the project summary on the official portal.

## Resources

- Qiskit: https://docs.quantum.ibm.com/
- Qiskit Aer simulator: https://docs.quantum.ibm.com/guides/simulators
- IBM Quantum Platform: https://quantum.cloud.ibm.com/
- NASA-USDA soil moisture: https://earth.gsfc.nasa.gov/hydro/data/nasa-usda-global-soil-moisture-data
- ISRIC SoilGrids: https://isric.org/explore/soilgrids/

## License

MIT. Include the repository's `LICENSE` file.
