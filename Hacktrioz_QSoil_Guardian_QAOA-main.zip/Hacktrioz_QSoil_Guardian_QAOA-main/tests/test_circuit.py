import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector
from src.circuit import build_qaoa_circuit, energy, expected_energy
from src.optimizer import exact_classical_baseline


def test_qaoa_circuit_qubit_count():
    qc = build_qaoa_circuit([0.1, 0.2, 0.3, 0.4], 2, [0.2, 0.4])
    assert qc.num_qubits == 4


def test_measurement_added_when_requested():
    qc = build_qaoa_circuit([0.1, 0.2, 0.3, 0.4], 2, [0.2, 0.4], measure=True)
    assert qc.num_clbits == 4


def test_statevector_probabilities_sum_to_one():
    qc = build_qaoa_circuit([0.1, 0.2, 0.3, 0.4], 2, [0.2, 0.4])
    assert abs(float(np.sum(Statevector.from_instruction(qc).probabilities())) - 1) < 1e-8


def test_energy_penalizes_wrong_budget():
    assert energy("1100", [0.1, 0.2, 0.3, 0.4], 2) < energy("1000", [0.1, 0.2, 0.3, 0.4], 2)


def test_classical_baseline_is_expected():
    answer = exact_classical_baseline([0.12, 0.56, 0.0, 0.36], 2)
    assert answer["bitstring"] == "0101"
    assert abs(answer["score"] - 0.92) < 1e-8
